let imageSources= ["Data/capa1.png","Data/capa3.png","Data/capa4.png","Data/capa6.png", "Data/capa5.png","Data/capa7.png"];

let currentIndex = 0;

let leftArrow = document.querySelector(".carousel svg:first-child");
let rightArrow = document.querySelector(".carousel svg:last-child");

leftArrow.addEventListener("click", function() {
    currentIndex = currentIndex - 1;
    if (currentIndex < 0) {
        currentIndex = imageSources.length-1;
    }
    document.querySelector(".carousel img").setAttribute("src", imageSources[currentIndex]);
});

rightArrow.addEventListener("click", function() {
    currentIndex = currentIndex + 1;
    if (currentIndex >= imageSources.length) {
        currentIndex = 0;
    }
    document.querySelector(".carousel img").setAttribute("src", imageSources[currentIndex]);
});


function allowDrop(ev) {
    ev.preventDefault();
}

function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));
}


/*para limpar a janela*/
console.clear();

var piscar = document.getElementById("piscar");

setInterval(aparecer, 2000);

function aparecer () {
    piscar.style.cssText="visibility:visible";
    setTimeout(desaparecer, 1000);
}

function desaparecer() {
    piscar.style.cssText="visibility:hidden";
}


